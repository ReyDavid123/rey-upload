from flask import Flask, redirect, render_template, request, url_for,make_response,Response,jsonify
import requests
import sys
from bs4 import BeautifulSoup
import os
import requests
from urllib.parse import urlparse
import base64
from gitlabcli import GitLabCli

import S5Crypto
from JDatabase import JsonDatabase
from utils import get_file_size

MASTER_AUTH = 'Obysoft2001@'


def get_db():
    jdb = JsonDatabase('database')
    jdb.check_create()
    jdb.load()
    return jdb


app = Flask(__name__)


@app.route("/cufreefile/api/addauth")
def addauth():
    result = {'status':'BAD'}

    args = None

    jdb = get_db()

    try:args=request.args
    except:pass

    if args:
        if 'username' in args:
            username = args['username']
            userdata = jdb.get_user(username)
            if userdata:
                result['error'] = 'Username Already Exist!'
            else:
                jdb.create_user(username)
                jdb.save()
                result['status'] = 'OK'

    return jsonify(result)


@app.route("/cufreefile/api/auth")
def auth():
    result = {'status':'BAD'}

    jdb = get_db()

    args = None

    try:args=request.args
    except:pass

    if args:
        if 'username':
            userdata = jdb.get_user(args['username'])
            if userdata:
               result['status'] = 'OK'
               result['token'] = S5Crypto.encrypt(args['username']+'|'+str(userdata['used_space'])+'|'+str(userdata['max_space']))
            else:
                result['error'] = 'No Authenticate'
    else:
        result['error'] = 'No Username In Args!'

    return jsonify(result)


@app.route("/cufreefile/api/direct",methods=['GET'])
def direct():
    args = None

    try:args=request.args
    except:pass

    if 'uri' in args:
        url = S5Crypto.decrypt(args['uri'])
        return redirect(url)

    return 'No Direct Url'

@app.route("/cufreefile/api/upload",methods=['POST','GET'])
def upload():
    result = {'status':'BAD','result':{}}

    jdb = get_db()

    jsondata = None

    try:jsondata=request.get_json()
    except:pass

    username = ''

    if jsondata:
        if 'token' not in jsondata:
            result['error'] = 'No Authenticate Token'
            return

        if 'token' in jsondata:
            token = jsondata['token']
            data = S5Crypto.decrypt(token).split('|')
            data[1] = int(data[1])
            data[2] = int(data[2])
            username = data[0]
            userdata = jdb.get_user(data[0])
            if userdata == None:
                result['error'] = 'No Authenticate Token'
                return
            else:
                if userdata['used_space'] != data[1] and userdata['max_space'] != data[2]:
                    result['error'] = 'No Authenticate Token'
                    return


        filename = jsondata['filename']
        data = base64.b64decode(jsondata['data'])
        with open(filename,'wb') as f:
            f.write(data)

        userdata = jdb.get_user(username)

        cli = GitLabCli(user='ObisoftDev',password='Obysoft2001@')
        loged = cli.login()

        data = None

        if loged:
            data = cli.upload_file(filename,user=username)
            if data:
                if 'url' in data:
                    if userdata:
                        userdata['used_space'] = userdata['used_space'] + get_file_size(filename)
                        jdb.save_data_user(username,userdata)
                        jdb.save()
                    data['url'] = 'https://cufreefile.net/v0.1/' + S5Crypto.encrypt(data['url'])

        os.unlink(filename)

        result['status'] = 'OK'
        if data:
            result['result'] = data
        pass
    else:
        result['error'] = 'No Json Data!'

    return jsonify(result)



if __name__ == '__main__':
    app.run(threaded=True, port=80)